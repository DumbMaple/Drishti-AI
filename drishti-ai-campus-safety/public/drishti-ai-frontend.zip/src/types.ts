export type RaipurCampusKey = 'ssipmt' | 'nit' | 'iiit' | 'aiims' | 'hnlu' | 'prsu';

export interface CampusTelemetry {
  id: string;
  name: string;
  shortName: string;
  location: string;
  status: 'SECURE' | 'OPTIMAL' | 'CROWD ALERT' | 'WARNING';
  cams: number;
  activeCams: number;
  crowdSaturation: string;
  crowdPct: number;
  breaches: number;
  falls: number;
  safetyScore: number;
  desc: string;
}

export type ConsoleTab =
  | 'dashboard'
  | 'live-monitoring'
  | 'cameras'
  | 'incidents'
  | 'risk-analytics'
  | 'campus-map'
  | 'reports'
  | 'settings';

export type AlertSeverity = 'Critical' | 'Moderate' | 'Low';

export interface Incident {
  id: string;
  time: string;
  cameraId: string;
  cameraName: string;
  location: string;
  eventType: 'Fall Detection' | 'Crowd Alert' | 'Unauthorized Entry' | 'Abnormal Activity' | 'Loitering';
  severity: AlertSeverity;
  confidence: number;
  description: string;
  modelEngine: 'MediaPipe Pose' | 'YOLOv8-Crowd' | 'YOLOv8x-Thermal' | 'DeepSORT-Track';
  status: 'Pending' | 'Acknowledged' | 'Dispatched' | 'Resolved';
}

export interface CameraFeed {
  id: string;
  name: string;
  zone: string;
  status: 'online' | 'warning' | 'alert' | 'offline';
  aiMode: string;
  peopleCount: number;
  fps: number;
  resolution: string;
  rtspUrl: string;
  lastActive: string;
  confidence: number;
  riskLevel: 'Safe' | 'Moderate' | 'Critical';
}

export interface ZoneRisk {
  id: string;
  name: string;
  riskScore: number;
  status: 'Safe' | 'Moderate' | 'Critical';
  camerasCount: number;
  alertsCount: number;
  activeIncidents: string[];
}
